import sys
sys.path.append('/home/pi/Desktop/Final_code')
from UART import close_door
close_door()
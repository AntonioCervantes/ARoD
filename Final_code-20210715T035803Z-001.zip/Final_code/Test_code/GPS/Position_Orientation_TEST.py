import sys
sys.path.append('/home/pi/Desktop/Final_code')
from Position_Orientation import magnetometer
while True:
    magnetometer()

import sys
sys.path.append('/home/pi/Desktop/Final_code')
from UART import *





avoidance_steering("left")
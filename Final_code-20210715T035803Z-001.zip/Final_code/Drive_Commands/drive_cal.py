import sys
sys.path.append('/home/pi/Desktop/Final_code')
from UART import *

drive_cal()
print('ESC Calibrating.....')
